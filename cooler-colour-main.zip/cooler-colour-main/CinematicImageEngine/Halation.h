#pragma once

#include <cmath>
#include <algorithm>

namespace Halation {

struct Params {
    bool enable;
    double amount;
    double threshold;
    double knee;    // Softness of the threshold
    double warmth;  // -1 (Red) to 1 (Orange/Yellow)
    double radius;  // Spatial radius
    double saturation; // To bound the color
};

// Helper: Rec.709 Luminance
inline float getLuminance(float r, float g, float b) {
    return 0.2126f * r + 0.7152f * g + 0.0722f * b;
}

inline float smoothstep_h(float edge0, float edge1, float x) {
    float t = std::max(0.0f, std::min(1.0f, (x - edge0) / (edge1 - edge0)));
    return t * t * (3.0f - 2.0f * t);
}

// Compute the source color that will be blurred
inline void computeHalationSource(float r, float g, float b, float skinMask,
                                  float& hR, float& hG, float& hB,
                                  const Params& params) {
    if (!params.enable || params.amount <= 0.0) {
        hR = hG = hB = 0.0f;
        return;
    }

    float L = getLuminance(r, g, b);

    // Highlight Mask
    float mask = smoothstep_h((float)params.threshold, (float)params.threshold + (float)params.knee, L);

    // Skin Preservation Attenuation
    // "Skin Preservation mask must attenuate halation contribution on skin"
    mask *= (1.0f - skinMask);

    if (mask <= 0.001f) {
        hR = hG = hB = 0.0f;
        return;
    }

    // Color Logic
    // Base is Red channel dominates.
    // Warmth:
    // -1.0 => Pure Red (G=0)
    // 0.0  => Default (Small G contribution for natural Orange-Red)
    // 1.0  => More Orange/Yellow (Higher G)

    // Base Green Mix
    float baseG = 0.1f; // Natural film scattering often has a bit of green/yellow
    float mixG = baseG + (float)params.warmth * 0.4f; // Range 0.1 +/- 0.4 -> -0.3 to 0.5?
    mixG = std::max(0.0f, mixG);

    // Source Channels
    // We use the pixel's R channel as the energy driver?
    // "Halation energy must be derived primarily from the RED channel"
    // So we scale the actual R value.
    float sourceEnergy = r;

    hR = sourceEnergy * mask;
    hG = sourceEnergy * mask * mixG; // Green derived from Red energy? Or Green channel?
    // Film physics: Red light scatters. So it's the Red component of the light source.
    // So yes, derived from R.

    hB = 0.0f; // Blue usually doesn't scatter significantly in this layer

    // Saturation Control (Simple scalar for now, or mix towards L?)
    // "Saturation control must be subtle and bounded"
    // We apply saturation to the resulting vector?
    // For source extraction, we just control the ratios.
    // The blur will mix them.
}

// Apply the blurred halation to the original pixel
inline void applyHalation(float* r, float* g, float* b,
                          float hBlurR, float hBlurG, float hBlurB,
                          const Params& params) {
    if (!params.enable || params.amount <= 0.0) return;

    // Additive blend
    // "Halation must be blended additively and asymptotically"
    // Optional soft clamp? "Never to 1.0".

    // Simple addition first
    float resultR = *r + hBlurR * (float)params.amount;
    float resultG = *g + hBlurG * (float)params.amount;
    float resultB = *b + hBlurB * (float)params.amount;

    // Asymptotic compression if needed?
    // "Optional soft clamp at extreme HDR values ONLY if mathematically required"
    // For now, linear add is HDR safe.

    *r = resultR;
    *g = resultG;
    *b = resultB;
}

}
