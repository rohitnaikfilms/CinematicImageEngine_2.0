#pragma once

#include <cmath>
#include <algorithm>
#include "Utils.h"

/**
 * @brief Photochemical Color Response (PCR) Module.
 *        Hue + saturation behavior driven strictly by luminance.
 *        STRICT SCOPE: NO luminance contrast, NO compression curves.
 */
class FilmResponse
{
public:
    struct Params
    {
        bool enable;
        double amount;
        double highlightWarmth;
        double highlightCompression;
        double midtoneColorFocus;
        double shadowCoolBias;
        // Prompt says "Shadow Cool Bias", "Midtone Color Focus", "Highlight Warmth", "Highlight Compression", "Amount".
        // It does NOT list "Shadow Range" or "Highlight Range" controls.
        // It says "Controls: Amount, Shadow Cool Bias, Midtone Color Focus, Highlight Warmth, Highlight Compression".
        // So I should remove range params and use fixed/safe defaults or implicit ranges.
    };

    static void processPixel(float* r, float* g, float* b, const Params& params)
    {
        if (!params.enable || params.amount <= 0.0) return;

        float R = *r;
        float G = *g;
        float B = *b;

        // 1. Compute Perceptual Luminance Y
        float Y = 0.2126f * R + 0.7152f * G + 0.0722f * B;

        // 2. Compute Chroma Vector C = RGB - Y
        float cR = R - Y;
        float cG = G - Y;
        float cB = B - Y;

        // Safety for chroma magnitude calculation
        float cMagSq = cR*cR + cG*cG + cB*cB;
        if (cMagSq < 1e-8f) return;

        // 3. Zones (Hardcoded ranges as controls are removed)
        // Shadows: 0.0 - 0.3
        // Mids: 0.3 - 0.7
        // Highlights: 0.7 - 1.0
        float shadowW = 1.0f - Utils::smoothstep(0.0f, 0.3f, Y);
        float highlightW = Utils::smoothstep(0.7f, 1.0f, Y);
        float midWeight = (1.0f - shadowW) * (1.0f - highlightW); // Peak at 0.5

        // 4. ZONES

        // --- SHADOWS ---
        // Cool Bias + Desaturation
        if (shadowW > 0.0f) {
             float bias = (float)params.shadowCoolBias * shadowW;
             // Desaturate:
             float desat = bias; // Link bias to desat? Or just bias.
             // Prompt: "Shadows: cool bias + desaturation"
             // Let's assume the slider controls intensity of BOTH.

             // Desaturate
             float satFactor = 1.0f - desat * 0.5f;
             cR *= satFactor; cG *= satFactor; cB *= satFactor;

             // Cool Bias Vector (Teal/Blue)
             // Vector: -R, +B
             // Normalize current chroma to add direction? Or just add vector?
             // Prompt "Operate in C = RGB - Y".
             // Adding constant vector shifts hue.

             // Scale bias by current saturation (so gray stays gray? or tint blacks?)
             // Usually film tint affects everything. But if cMag is 0 (gray), should we tint?
             // "Photochemical... hue + saturation".
             // If input is B&W, film response might still tint it.
             // But cMag check at top prevents processing grays.
             // If we want to tint grays, we shouldn't exit early.
             // BUT "Operate in C = RGB - Y". If R=G=B=Y, then C=0.
             // If we add bias to C=0, then C becomes non-zero, creating color.
             // Let's allow tinting grays.

             float bStr = bias * 0.05f; // Small shift
             cR -= bStr;      // Less Red
             cB += bStr * 1.5f; // More Blue
             cG += bStr * 0.2f; // Slight Green for Teal
        }

        // --- MIDTONES ---
        // Saturation Peak
        if (midWeight > 0.0f) {
            float satBoost = (float)params.midtoneColorFocus * midWeight; // 0..1
            float factor = 1.0f + satBoost;
            cR *= factor; cG *= factor; cB *= factor;
        }

        // --- HIGHLIGHTS ---
        // Warm Bias + Channel-aware Desaturation
        if (highlightW > 0.0f) {
            float hStr = (float)params.highlightWarmth * highlightW;
            float hComp = (float)params.highlightCompression * highlightW;

            // Warm Bias (Gold: +R, +G, -B)
            float wStr = hStr * 0.05f;
            cR += wStr;
            cG += wStr * 0.5f;
            cB -= wStr;

            // Compression (Channel dependent)
            // Red compresses fastest -> reduces R chroma more?
            // "Dye exhaustion".
            // If we reduce C, we desaturate.
            // Reduce R more than G/B.
            cR *= (1.0f - hComp * 1.0f);
            cG *= (1.0f - hComp * 0.5f);
            cB *= (1.0f - hComp * 0.2f);
        }

        // 5. Reconstruct
        float R_new = Y + cR;
        float G_new = Y + cG;
        float B_new = Y + cB;

        // 6. Master Blend
        float amt = (float)params.amount;
        *r = Utils::mix(R, R_new, amt);
        *g = Utils::mix(G, G_new, amt);
        *b = Utils::mix(B, B_new, amt);
    }
};
