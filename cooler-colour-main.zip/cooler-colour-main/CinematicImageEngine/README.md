# Dreamy Mist OpenFX Plugin

A cinematic mist filter for DaVinci Resolve on macOS (Apple Silicon).
This plugin creates a dreamy, light-scattering effect based on photographic highlight diffusion principles.

## Features

- **Photographic Mist Model**: Uses highlight isolation (Rec.709 Luminance) and smooth thresholding.
- **Optimized Performance**: Fast, separable sliding-window box blur (CPU only).
- **Energy Conserving**: Additive blending that preserves blacks and shadows.
- **Cinematic Warmth**: Optional warmth control for the mist layer.
- **Resolution Independent**: Blur radius scales with render resolution.

## Compatibility

- **Host**: DaVinci Resolve 17/18/19 (Color Page)
- **Platform**: macOS (Apple Silicon arm64 / Intel x86_64)
- **OpenFX Version**: 1.4

## Build Instructions

### Prerequisites
- CMake 3.10+
- Xcode Command Line Tools or clang
- OpenFX 1.4 Headers (included in repo)

### Building
```bash
cd DreamyMist
mkdir build
cd build
cmake ..
make
```

The output will be a bundle: `DreamyMist.ofx.bundle`.

## Installation

Move the generated bundle to the standard OpenFX directory:

```bash
sudo cp -r DreamyMist.ofx.bundle /Library/OFX/Plugins/
```

Restart DaVinci Resolve.

## Controls

- **Mist Amount**: Overall intensity of the effect.
- **Highlight Threshold**: Luminance level where mist generation begins. Lower values affect more midtones.
- **Softness**: The radius of the mist spread.
- **Warmth**: Shift the mist color towards orange (warm) or blue (cool).
- **Enable**: Toggle the effect.

## Version
1.0.0
