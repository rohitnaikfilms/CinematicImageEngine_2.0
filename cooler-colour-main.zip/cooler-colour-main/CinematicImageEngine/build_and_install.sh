#!/bin/bash

# Pull latest changes
git pull origin main

# Clean previous build
rm -rf build

# Create build directory
mkdir build && cd build

# Configure and Build
cmake .. && make

# Install (Requires Password)
echo "Installing to /Library/OFX/Plugins..."
sudo cp -r CinematicImageEngine.ofx.bundle /Library/OFX/Plugins
