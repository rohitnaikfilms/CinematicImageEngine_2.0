#pragma once

#include <cmath>
#include <algorithm>

/**
 * @brief Tonal Engine Module.
 *
 * PURPOSE:
 * Reshape tonal response around a defined pivot.
 * Now absorbs Shadow Protection (Black Floor).
 *
 * MATH MODEL:
 * L = 0.2126*R + 0.7152*G + 0.0722*B
 * Lout = Pivot * (Lin / Pivot)^Contrast
 * Lout = max(Lout, BlackFloor)
 */
class TonalEngine
{
public:
    struct Params
    {
        double contrast;   // > 0, default 1.0
        double pivot;      // > 0, default 0.18
        double strength;   // 0.0 .. 1.0
        double blackFloor; // 0.0 .. 0.1
    };

    static void processPixel(float* r, float* g, float* b, const Params& params)
    {
        float R = *r;
        float G = *g;
        float B = *b;

        // 1. Compute Perceptual Luminance (Rec.709 coefficients)
        float L = 0.2126f * R + 0.7152f * G + 0.0722f * B;

        const float epsilon = 1e-7f;

        // 2. Normalize Luminance around Pivot
        float safePivot = (float)std::max(params.pivot, 1e-4);
        float Ln = std::max(L / safePivot, epsilon);

        // 3. Apply Power-based Tonal Shaping
        float Lc = std::pow(Ln, (float)params.contrast);

        // 4. Restore Luminance Scale
        float L_mapped = Lc * safePivot;

        // 5. Strength-Controlled Blending
        float str = std::min(std::max((float)params.strength, 0.0f), 1.0f);
        float L_out = L * (1.0f - str) + L_mapped * str;

        // 6. Black Floor (Shadow Protection integration)
        if (params.blackFloor > 0.0) {
            L_out = std::max(L_out, (float)params.blackFloor);
        }

        // 7. RGB Reapplication (Preserve Chroma)
        float ratio = L_out / std::max(L, epsilon);

        *r = R * ratio;
        *g = G * ratio;
        *b = B * ratio;
    }
};
