#pragma once

#include "Utils.h"
#include <cmath>
#include <algorithm>

class Vignette {
public:
    enum Type {
        eDark = 0,
        eLight = 1,
        eDefocus = 2
    };

    struct Params {
        bool enable;
        int type; // Type enum
        double amount;
        bool invert;
        double size;
        double roundness;
        double edgeSoftness;
        double defocusAmount;
        double defocusSoftness;
        // Center? Default to center.
    };

    // Calculate Mask only.
    // x, y are normalized coords? Or pixel coords?
    // "Resolution independent".
    // We should pass UV (0..1) or normalized coords.
    // Let's expect UV.
    static float computeMask(float u, float v, float aspect, const Params& p) {
        // Center (0.5, 0.5)
        float cx = 0.5f;
        float cy = 0.5f;
        float dx = u - cx;
        float dy = v - cy;

        // Aspect correction: multiply x by aspect? or y?
        // Usually, vignette is circular in image space, so stretched if aspect != 1.
        // Or circular in square space.
        // Let's correct for aspect to get circular.
        // If aspect > 1 (Wide), x range is wider.
        // dx *= aspect? No.
        // If we want a circle on screen, we need distance in pixels.
        // If u goes 0..1, x_px = u * W.
        // dist_px = sqrt((dx*W)^2 + (dy*H)^2).
        // = sqrt(dx^2 * W^2 + ...).
        // Let's just use aspect ratio to scale one axis.
        if (aspect > 1.0f) {
             dx *= aspect; // Correct x deviation to match y scale
        } else {
             dy /= aspect; // Correct y deviation
        }

        // Roundness (Square vs Circle)
        // Roundness 1.0 = Circle. 0.0 = Square (Rect).
        // Distance metric.
        // Circle: sqrt(dx^2 + dy^2).
        // Square: max(|dx|, |dy|).
        float dCircle = std::sqrt(dx*dx + dy*dy);
        float dSquare = std::max(std::abs(dx), std::abs(dy));

        // Let's implement Roundness as mixing metrics.
        // Or superellipse.
        // Mix is easier.
        float dist = Utils::mix(dSquare, dCircle, (float)p.roundness);

        // Size
        // Size 1.0 -> Corners visible?
        // Let's say Size controls "Radius" where falloff starts or ends.
        // Standard: dist goes from 0 to ~0.7 (corner).
        // Size param: 0..1.
        // Map Size to a Radius value.
        // Higher size -> Larger clear area.
        // Radius = size * 0.8 + 0.2?
        float radius = (float)p.size; // 0..1

        // Softness
        // Smoothstep edges.
        // inner = radius * (1 - softness)
        // outer = radius
        // Wait, usually vignette starts at some radius and falls off.
        // Let's define:
        // Mask V = 0 (Center) to 1 (Edge).
        // V = smoothstep(inner, outer, dist).
        // If size is large, inner is large.

        float outer = 1.0f; // Max distance usually covers frame.
        // Let's inverse logic. Size = "Vignette Free Area".
        // V = smoothstep(size, size + softness, dist).
        float softness = std::max(0.01f, (float)p.edgeSoftness);
        float start = (float)p.size * 0.7f; // Scale to reasonable UV distance
        float end = start + softness;

        float V = Utils::smoothstep(start, end, dist);
        return V;
    }

    static void processPixel(float* r, float* g, float* b, float V, float skinMask, const Params& p) {
        if (!p.enable) return;

        // Invert Logic
        // Invert toggle swaps Dark/Light behavior?
        // "Invert toggle must swap dark/light behavior cleanly".
        // Actually, V goes 0 (Center) -> 1 (Edge).
        // If Invert=True, V goes 1 (Center) -> 0 (Edge)?
        // Or just apply effect inversely?
        // Prompt: "Invert ... must not affect softness or shape".
        // So just invert V?
        // If Invert, V = 1.0 - V.
        // Dark Vignette: Darkens where V is high.
        // If Invert mask, we darken center. Correct.

        float mask = p.invert ? (1.0f - V) : V;

        // Attenuate by Skin (Don't vignette faces)
        // If Dark/Light vignette, usually we want to preserve faces.
        // Mask * (1 - skinMask).
        mask *= (1.0f - skinMask);

        if (mask <= 0.0f) return;

        float amount = (float)p.amount;

        if (p.type == eDark || p.type == eLight) {
             // Exposure based
             // L_out = L * (1.0 + amount * V)
             // amount: -1 (Dark) to +1 (Light).
             // Params has "amount" 0..1 usually?
             // Type eDark -> amount is negative effect.
             // Type eLight -> amount is positive effect.

             float effAmount = 0.0f;
             if (p.type == eDark) effAmount = -amount;
             else effAmount = amount;

             float L = Utils::getLuminance(*r, *g, *b);
             float L_out = L * (1.0f + effAmount * mask);
             // Clamp L_out >= 0
             L_out = std::max(0.0f, L_out);

             // Reapply to RGB
             float scale = (L > 1e-6f) ? (L_out / L) : 1.0f;
             *r *= scale;
             *g *= scale;
             *b *= scale;
        }
        else if (p.type == eDefocus) {
             // Handled separately or requires blur input?
             // Prompt: "Attenuate detail... No global blur allowed."
             // "Extract high-frequency detail layer... Recombine".
             // This requires spatial data (Detail layer).
             // If we are per-pixel here, we can't do Defocus unless we have Detail.
             // PipelineProcessor handles this?
             // Yes. This function might just return the mask or handle color parts.
             // For Defocus, we need to handle it in PipelineProcessor using the mask computed here.
             // So `processPixel` just does color/exposure.
             // Defocus is handled by caller using `computeMask`.
        }
    }
};
