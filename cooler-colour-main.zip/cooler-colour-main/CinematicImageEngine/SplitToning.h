#pragma once

#include "Utils.h"
#include <cmath>
#include <algorithm>

namespace SplitToning {

struct Params {
    bool enable;
    float strength;
    float shadowHue;
    float highlightHue;
    float balance;
};

// Map Hue (Degrees) to unit vector
inline void hueToPbPr(float hueDeg, float& pb, float& pr) {
    float rad = hueDeg * 0.0174532925f; // PI / 180
    pb = std::cos(rad);
    pr = std::sin(rad);
}

inline void processPixel(float* r, float* g, float* b, const Params& params) {
    if (!params.enable || params.strength <= 0.0f) return;

    // 1. LUMINANCE
    float L = 0.2126f * (*r) + 0.7152f * (*g) + 0.0722f * (*b);

    // 2. WEIGHTS
    // Shadow: 1 at 0, 0 at 0.5
    // Highlight: 0 at 0.5, 1 at 1
    float shadowW = 1.0f - Utils::smoothstep(0.0f, 0.5f, L);
    float highlightW = Utils::smoothstep(0.5f, 1.0f, L);

    // Balance
    // -1 (Shadows) -> +1 (Highlights)
    // Shift the weighting crossover?
    // Or just multiply amplitudes.
    // Prompt: "Balance weighs the blend between Shadow and Highlight"
    // Let's use simple multiplier logic:
    // if balance < 0: boost shadowW, reduce highlightW?
    // Actually, balance -1 means mostly shadow tint.

    // Remap balance -1..1 to 0..2 factors approx
    float sFactor = 1.0f - params.balance; // 2.0 at -1, 0.0 at 1
    float hFactor = 1.0f + params.balance; // 0.0 at -1, 2.0 at 1

    // Normalize slightly so at 0 both are 1.

    shadowW *= sFactor;
    highlightW *= hFactor;

    // 3. VECTORS
    float sPb, sPr, hPb, hPr;
    hueToPbPr(params.shadowHue, sPb, sPr);
    hueToPbPr(params.highlightHue, hPb, hPr);

    // Combine
    float dPb = (sPb * shadowW + hPb * highlightW) * params.strength * 0.05f; // Scale down for subtlety
    float dPr = (sPr * shadowW + hPr * highlightW) * params.strength * 0.05f;

    // 4. APPLY (Preserving L)
    // NewR = R + dPr / 0.6350
    // NewB = B + dPb / 0.5389
    // NewG = derived

    float newR = *r + dPr / 0.6350f;
    float newB = *b + dPb / 0.5389f;
    // Calculate G to maintain exact luminance L
    float newG = (L - 0.2126f * newR - 0.0722f * newB) / 0.7152f;

    *r = newR;
    *g = newG;
    *b = newB;
}

}
