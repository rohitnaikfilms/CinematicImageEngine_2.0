#pragma once

#include <cmath>
#include <algorithm>
#include <vector>

namespace Utils {

inline float smoothstep(float edge0, float edge1, float x) {
    if (edge1 <= edge0) return x >= edge1 ? 1.0f : 0.0f;
    float t = std::max(0.0f, std::min(1.0f, (x - edge0) / (edge1 - edge0)));
    return t * t * (3.0f - 2.0f * t);
}

inline float getLuminance(float r, float g, float b) {
    return 0.2126f * r + 0.7152f * g + 0.0722f * b;
}

inline float mix(float x, float y, float a) {
    return x * (1.0f - a) + y * a;
}

// Separable Gaussian Blur (Horizontal + Vertical pass concept)
// Since this is just Utils, we can implement a generic buffer blur.
// src and dst must be RGBA float buffers of size w*h*4.
// This is CPU implementation, so simple O(N*R) per axis.
inline void gaussianBlur(const float* src, float* dst, int w, int h, int r) {
    if (r < 1) {
        std::copy(src, src + w * h * 4, dst);
        return;
    }

    std::vector<float> temp(w * h * 4);

    // Horizontal Pass
    // 1D Kernel approx: just box blur or actual gaussian?
    // Prompt says "Blur (Separable Gaussian)".
    // Let's do a simple box blur 3 times or true gaussian.
    // For speed and simplicity in Utils, let's do a sliding window or simple kernel.
    // True Gaussian kernel generation:

    int kSize = 2 * r + 1;
    std::vector<float> kernel(kSize);
    float sigma = (float)r / 2.0f; // Approx
    if (sigma < 0.1f) sigma = 0.1f;
    float sum = 0.0f;
    for(int i = 0; i < kSize; ++i) {
        float x = (float)(i - r);
        kernel[i] = std::exp(-(x*x) / (2 * sigma * sigma));
        sum += kernel[i];
    }
    for(int i = 0; i < kSize; ++i) kernel[i] /= sum;

    // H Pass: Src -> Temp
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            float rgb[3] = {0,0,0};
            for (int k = -r; k <= r; ++k) {
                int px = std::min(std::max(x + k, 0), w - 1);
                float weight = kernel[k + r];
                const float* p = &src[(y * w + px) * 4];
                rgb[0] += p[0] * weight;
                rgb[1] += p[1] * weight;
                rgb[2] += p[2] * weight;
            }
            int idx = (y * w + x) * 4;
            temp[idx+0] = rgb[0];
            temp[idx+1] = rgb[1];
            temp[idx+2] = rgb[2];
            temp[idx+3] = src[idx+3]; // Alpha copy
        }
    }

    // V Pass: Temp -> Dst
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            float rgb[3] = {0,0,0};
            for (int k = -r; k <= r; ++k) {
                int py = std::min(std::max(y + k, 0), h - 1);
                float weight = kernel[k + r];
                const float* p = &temp[(py * w + x) * 4];
                rgb[0] += p[0] * weight;
                rgb[1] += p[1] * weight;
                rgb[2] += p[2] * weight;
            }
            int idx = (y * w + x) * 4;
            dst[idx+0] = rgb[0];
            dst[idx+1] = rgb[1];
            dst[idx+2] = rgb[2];
            dst[idx+3] = temp[idx+3];
        }
    }
}

}
