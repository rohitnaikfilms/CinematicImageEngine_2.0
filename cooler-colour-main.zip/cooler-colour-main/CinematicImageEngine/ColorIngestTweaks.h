#pragma once
#include "Utils.h"

namespace ColorIngestTweaks {

struct Params {
    double exposureTrim;
    double chromaCeiling;
    double whiteBias; // -1.0 (Cool) to 1.0 (Warm)
    bool enable;
};

inline void process(float* r, float* g, float* b, const Params& p) {
    if (!p.enable) return;

    // 1. Exposure Trim
    // RGB *= 2^trim
    if (p.exposureTrim != 0.0) {
        float gain = std::pow(2.0f, (float)p.exposureTrim);
        *r *= gain;
        *g *= gain;
        *b *= gain;
    }

    // 2. Chroma Ceiling
    // Soft compress chroma vector if magnitude > limit
    // Simple chroma approx: max(r,g,b) - min(r,g,b) or vector from luma
    // Let's use generic approximation for speed: C = RGB - Y
    // But accurate saturation is usually S = Max - Min / Max or similar.
    // The prompt says: "If |C| > limit -> soft compress chroma vector"
    // Let's use YUV-ish approach.
    if (p.chromaCeiling < 1.0) {
        float luma = 0.2126f * (*r) + 0.7152f * (*g) + 0.0722f * (*b);
        float cr = *r - luma;
        float cg = *g - luma;
        float cb = *b - luma;

        // Chroma magnitude (approx)
        float cMag = std::sqrt(cr*cr + cg*cg + cb*cb);

        // Limit is mapped from 0-100% slider.
        // 100% (1.0) = No compression? Or 1.0 = Max saturation?
        // Prompt says "Chroma Ceiling (0-100%)".
        // Let's assume 1.0 is "Standard Rec709 max" approx.
        // If slider is 100, no ceiling? Or slider sets the ceiling value?
        // Let's assume slider sets the LIMIT. 1.0 = Allow full. 0.0 = B&W.

        float limit = (float)p.chromaCeiling;
        // Avoid div by zero
        if (cMag > limit && limit > 0.001f) {
            // Soft compress: tanh or simple ratio
            // target = limit + (cMag - limit) * ratio?
            // "soft compress"
            float compressed = limit + std::tanh(cMag - limit) * 0.1f; // Hard knee
            // Let's just scale down
            float scale = compressed / cMag;
            *r = luma + cr * scale;
            *g = luma + cg * scale;
            *b = luma + cb * scale;
        } else if (limit <= 0.001f) {
             *r = luma; *g = luma; *b = luma;
        }
    }

    // 3. Highlight White Bias
    // Apply very small chroma vector at high luminance only
    if (p.whiteBias != 0.0) {
        float luma = 0.2126f * (*r) + 0.7152f * (*g) + 0.0722f * (*b);
        // Only affect highlights, e.g., > 0.5
        if (luma > 0.5f) {
            float factor = (luma - 0.5f) * 2.0f; // 0 to 1
            factor = factor * factor; // smooth

            // Bias vector: Warm (Orange/Yellow) vs Cool (Blue)
            // Warm: +R, +G, -B. Cool: -R, -G, +B.
            float biasStrength = (float)p.whiteBias * 0.05f * factor; // Very subtle

            if (p.whiteBias > 0) { // Warm
                *r += biasStrength;
                *g += biasStrength * 0.8f;
                *b -= biasStrength;
            } else { // Cool
                *r -= std::abs(biasStrength);
                *g -= std::abs(biasStrength) * 0.2f;
                *b += std::abs(biasStrength);
            }
        }
    }
}

} // namespace
