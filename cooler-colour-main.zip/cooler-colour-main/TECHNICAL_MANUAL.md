# Cinematic Image Engine - Technical Reference Manual

## 1. Overview
The **Cinematic Image Engine** is a high-performance, modular OpenFX plugin for DaVinci Resolve designed to emulate the photochemical and optical characteristics of motion picture film.

The engine operates in a strict, ordered pipeline. It relies on DaVinci Resolve's Color Management (RCM) or Color Space Transforms (CST) for initial decoding and linearization.

## 2. Pipeline Architecture & Performance

The pipeline executes in a **FIXED CANONICAL ORDER**. This order is mathematically critical and cannot be changed by the user.

### Pipeline Order
1.  **[Resolve CST / RCM]** (External Host Process)
2.  **Color Ingest Tweaks** (Perceptual Conditioning)
3.  **Photochemical Color Response** (Hue/Sat Behavior)
4.  **Tonal Engine** (Contrast & Dynamic Range)
5.  **Color Energy Engine** (Density & Separation)
6.  **Highlight Protection** (Luminance Safety)
7.  **Split Toning** (Chromatic Bias)
8.  **Film Grain** (Texture)
9.  **Spatial Modules** (Mist, Blur, Glow, Sharpen, Halation, Vignette)

### Performance Categorization

#### Stage 0: Per-Pixel Processing (Fast)
*   **Modules:** Color Ingest, Film Response, Tonal Engine, Color Energy, Highlight Protection, Split Toning, Film Grain.
*   **Complexity:** O(1) per pixel. Cost scales linearly with resolution.
*   **Math:** Deterministic, CPU-optimized, no per-pixel trigonometry or pow() where avoidable.

#### Stage 1: Spatial Processing (Expensive)
*   **Modules:** Mist, Blur, Glow, Sharpen, Halation, Vignette (Defocus).
*   **Complexity:** O(R^2). These modules utilize convolution or neighborhood sampling.
*   **Impact:** Increases the "Region of Interest" (apron) fetched from the host. Cost increases significantly with Radius.

---

## 3. Module Reference

### 1. Color Ingest Tweaks (CIT)
**Role:** Lightweight perceptual conditioning immediately after Resolve's CST.
**Operations:**
*   **Exposure Trim:** Linear RGB gain ($RGB \times 2^{trim}$).
*   **Chroma Ceiling:** Soft compression of extreme saturation vectors (Neon suppression).
*   **Highlight White Bias:** Subtle chroma vector addition at high luminance (Cool/Warm white point shift).

### 2. Photochemical Color Response (PCR)
**Role:** Emulates film color behavior (Hue & Saturation) driven strictly by Luminance.
**Strict Scope:** NO contrast or compression curves.
**Math Model:**
*   Operates on Chroma ($C = RGB - Y$).
*   **Shadows:** Cool bias + Desaturation.
*   **Midtones:** Saturation Peak.
*   **Highlights:** Warm bias + Channel-aware desaturation (Dye exhaustion).

### 3. Tonal Engine
**Role:** The sole module for Luminance shaping and Contrast.
**Math Model:** Pivoted Power Function.
$$L_{out} = Pivot \times (L_{in} / Pivot)^{Contrast}$$
*   **Black Floor:** Hard limits the lowest black level ($max(L_{out}, Floor)$).
**Controls:** Contrast, Pivot, Strength, Black Floor.

### 4. Color Energy Engine
**Role:** Controls the relationship between Chroma energy and Luminance (Density and Separation).
**Merged Functionality:** Replaces standalone Color Density and Color Separation.
**Math:**
*   **Density:** $C_{dense} = C^{power}$. Deepens colors as they get saturated.
*   **Separation:** Expands chroma vectors away from neutral.
*   **Attentuation:** Effect is rolled off at Shadow and Highlight extremes to prevent artifacts.

### 5. Highlight Protection
**Role:** Luminance-only super-white compression.
**Math:** Asymptotic compression ($f(x) = x / (1 + kx)$).
**Controls:**
*   **Preserve Color:**
    *   *On:* Scales RGB ratios (Natural desaturation to white).
    *   *Off:* Compresses channels individually.

### 6. Split Toning (Simplified)
**Role:** Applies subtle chromatic bias to Shadows and Highlights.
**Math:** Additive Pb/Pr chroma vectors weighted by luminance.
**Controls:** Enable, Strength, Shadow Hue, Highlight Hue, Balance.

### 7. Film Grain
**Role:** Photochemical density noise.
**Core Rules:**
*   Multiplicative ($Pixel \times (1 + Grain)$).
*   Monochromatic.
*   Resolution Independent (scales with image dimensions).
*   **Presets:** 8mm, 16mm, Super 16, 35mm, 65mm, Clean.

### 8. Spatial Modules
*   **Dreamy Mist:** Highlight diffusion (Bloom).
*   **Dreamy Blur:** Optical softening (Soft Light blend).
*   **Cinematic Glow:** Specular emission (Add blend).
*   **Sharpening:** Detail enhancement.
*   **Halation:** Film scattering (Red fringe).
*   **Vignette:** Lens falloff.

---

## 4. Development Constraints
*   **Input:** All controls are Sliders, Toggles, or Dropdowns. No manual text entry.
*   **Optimization:** CPU-only, float precision.
*   **Dependencies:** Relies on OpenFX C++ Support Library.
